//
//  InfoViewController.swift
//  epamPractice1_GuessNumber
//
//  Created by Anna Krasilnikova on 30.01.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import UIKit

class InfoViewController: UIViewController {

    @IBOutlet weak var maxTries: UILabel!
    @IBOutlet weak var minTries: UILabel!
    @IBOutlet weak var countGames: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
            getInfo()
    }
    
    @IBAction func backToMainButtonTapped(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    @IBAction func clearInfo(_ sender: Any) {
        setInfo (maxTries: "-", minTries: "-", countGames: 0)
        getInfo()
    }
    
    func getInfo (){
        maxTries.text = UserDefaults.standard.string(forKey: InfoKeys.maxTriesKey.rawValue)
        minTries.text = UserDefaults.standard.string(forKey: InfoKeys.minTriesKey.rawValue)
        countGames.text = UserDefaults.standard.string(forKey: InfoKeys.countGamesKey.rawValue)
    }
    
    func setInfo (maxTries: String, minTries: String, countGames: Int){
        UserDefaults.standard.set(maxTries, forKey: InfoKeys.maxTriesKey.rawValue)
        UserDefaults.standard.set(minTries, forKey: InfoKeys.minTriesKey.rawValue)
        UserDefaults.standard.set(countGames, forKey: InfoKeys.countGamesKey.rawValue)
    }
}
