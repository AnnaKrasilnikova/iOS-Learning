//
//  ViewController.swift
//  epamPractice1_GuessNumber
//
//  Created by Vladimir romashov on 23.01.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import UIKit

class GuessNumberViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

