//
//  NavigationItem.swift
//  practice2_StarWarsDatabank
//
//  Created by Vladimir romashov on 14.02.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import UIKit

class NavigationItem: UINavigationItem {

}
