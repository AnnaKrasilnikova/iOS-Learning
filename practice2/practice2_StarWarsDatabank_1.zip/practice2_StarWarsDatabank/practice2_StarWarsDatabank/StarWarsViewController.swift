//
//  StarWarsViewController.swift
//  practice2_StarWarsDatabank
//
//  Created by Anna Krasilnikova on 14.02.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import UIKit

class StarWarsViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    final let urlString = "https://swapi.co/api/people"
    var characterNamesArray = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        getInfoFromUrl()
    }

    func getInfoFromUrl (){
        let url = NSURL(string: urlString)
        URLSession.shared.dataTask(with: (url as URL?)!, completionHandler: {(data, response, error) ->
            Void in
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                if let charactesArray = jsonObj.value(forKey: "results") as? NSArray{
                    for character in charactesArray {
                        if let characterInfo = character as? NSDictionary{
                            if let name = characterInfo.value(forKey: "name"){
                                self.characterNamesArray.append(name as! String)
                            }
                            OperationQueue.main.addOperation({
                                self.tableView.reloadData()
                            })
                        }
                    }
                }
            }
        }).resume()
    }
    
    func getInfoFromUrl1 (){
        let url = NSURL(string: urlString)
        var downoadTask = URLRequest(url: (url as URL?)!, cachePolicy: URLRequest.CachePolicy.reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 20)
        downoadTask.httpMethod = "GET"
        URLSession.shared.dataTask(with: downoadTask, completionHandler: {(data, response, error) ->
            Void in
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments){
                print(jsonObj)
            }
        }).resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return characterNamesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "characterCell") as! CharacterTableViewCell
        cell.characterLabel.text = characterNamesArray[indexPath.row]
        return cell
    }
}

