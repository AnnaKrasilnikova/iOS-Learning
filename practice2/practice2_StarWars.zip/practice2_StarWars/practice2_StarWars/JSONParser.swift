//
//  JSONParser.swift
//  practice2_StarWars
//
//  Created by Anna Krasilnikova on 14.02.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import Foundation

class JSONParser {
    static func parseJson(data: Data) -> [String: AnyObject]? {
        let options = JSONSerialization.ReadingOptions()
        do {
            let json = try JSONSerialization.jsonObject(with: data, options: options) as? [String: AnyObject]
            if let json = json {
                print("*** Here is the JSON")
                print(json)
                print("*** ***")
            }
            return json
        }
        catch (let parsingError) {
            print(parsingError)
        }
        return nil
    }
}
