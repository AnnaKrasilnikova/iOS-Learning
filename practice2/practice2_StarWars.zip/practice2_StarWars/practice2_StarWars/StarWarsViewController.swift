//
//  ViewController.swift
//  practice2_StarWars
//
//  Created by Anna Krasilnikova on 13.02.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import UIKit

class StarWarsViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var characters: [Character] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func getDataFromSwapi (){
        
        let swapiUrl = URL(string: "http://swapi.co/api/people")!
        let task = URLSession.shared.dataTask(with: swapiUrl) { (data, response, error) in
            if let response = response {
                print("Data encoding: \(String(describing: response.textEncodingName))")
            }
            if let error = error {
                NSLog("Got an error!: \(error.localizedDescription)")
                return
            }
            if let data = data {
                NSLog("Got \(data.count) bytes.")
                let str = String(data: data, encoding: String.Encoding.isoLatin1)
                
                print("*** Here are the string contents:")
                print(str!)
                print("*** ***")
                
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                
                if (statusCode == 200) {
                    print("Status code = \(statusCode)")
                    print("Everyone is fine, json downloaded successfully.")
                }
                let possibleJson = JSONParser.parseJson(data: data)
                if let json = possibleJson {
                    self.characters = []
                    print(json["results"] as Any)
                    
                    guard let people = json["results"] as? NSArray else { return }
                    
                    for person in people {
                        guard let personDict = person as? NSDictionary else { continue }
                        guard let name = personDict["name"] as? String else { continue }
                        guard let homeworld = personDict["homeworld"] as? String else { continue }
                        self.characters.append(Character(name: name, homeworld: homeworld))
                    }
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                        
                        if let next = json["next"] as? String {
                            self.nextPageUrl = next
                        } else {
                            self.nextPageUrl = nil
                        }
                        self.nextButton.enabled = self.nextPageUrl != nil
                        
                        if let prev = json["previous"] as? String {
                            self.prevPageUrl = prev
                        } else {
                            self.prevPageUrl = nil
                        }
                        self.prevButton.enabled = self.prevPageUrl != nil
                    }
                }
            }
        }
        task.resume()
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    // grouped vertical sections of the tableview
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    // #warning Incomplete implementation, return the number of rows
    // total row count goes here
        return characters.count
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    // at init/appear ... this runs for each visible cell that needs to render
        let cell = tableView.dequeueReusableCellWithIdentifier("charactercell", forIndexPath: indexPath) as! CharacterTableViewCell
        let i: Int = indexPath.row
    
        cell.characterName?.text = "\(characters[i].name)"
    
        return cell
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let detail = self.storyboard!.instantiateViewControllerWithIdentifier("characterViewController") as! CharacterViewController
    
        self.navigationController?.pushViewController(detail, animated: true)
    
        detail.getData = { [ weak self ] in
            return self!.characters[ indexPath.row ]
        }
    }

    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Star Wars API"
    }
}

