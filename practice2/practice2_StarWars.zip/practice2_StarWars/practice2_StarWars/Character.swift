//
//  Character.swift
//  practice2_StarWars
//
//  Created by Anna Krasilnikova on 14.02.2020.
//  Copyright © 2020 Anna Krasilnikova. All rights reserved.
//

import Foundation

class Character {
    var name: String
    var homeworld: String
    
    init(name: String, homeworld: String) {
        self.name = name
        self.homeworld = homeworld
    }
}
